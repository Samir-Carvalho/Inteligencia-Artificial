﻿* GCC129 - Sistemas Distribuídos.
 *    *  Universidade Federal de Lavras.
 *

*  Algoritmo para resolução do jogo dos oito.
 *         
 
* Professor: AHMED ALI ABDALLA ESMIN - DOCENTE - DCC.
 * Turma: 14.A - Sistemas de Informação.
 *
* @author Valdeci Soares da Silva Junior 
 *

* @author Lucas Danielian Ferrara de jesus 
 *


* O Trabalho foi desenvolvido com java versão 8 utilizando o NetBeans IDE e 
NetBeans Platform que são baseados em software da netbeans.org, 
que tem licenciamento duplo sob a Licença de Desenvolvimento e Distribuição Comum (CDDL)
e a GNU General Public License versão 2 com excepção do Classpath.
Product Version: NetBeans IDE 8.2 (Build 201609300101)
 *

*Atualizações: O IDE NetBeans está atualizado para a versão NetBeans 8.2 Patch 2 
Java: 1.8.0_121; Java HotSpot(TM) 64-Bit Server VM 25.121-b13 
Runtime: Java(TM) SE Runtime Environment 1.8.0_121-b13 
System: Linux version 4.8.0-56-generic running on amd64; UTF-8; pt_BR (nb) User 
directory: /home/junior/.netbeans/8.2 Cache 
directory: /home/junior/.cache/netbeans/8.2

 *

*Para o bom desempenho do sistema é altamente recomendado que se utilize a 
plataforma do netbeans uma vez que os testes foram feitos somente para esta plataforma.
    NÃO é necessário realizar configuração de execucao do pacote. *



# Como executar sem o Netbeans pelo terminal com ARQUIVO.JAR - Linux?

    O projeto possui binário associado para execução. 
    Para isso, você NÃO precisará compilar todos os código antes de executar a aplicação. 
    Abra o terminal do linux, navegue até o diretório principal(JogoDosOito) e executa os seguintes comandos:



````

$
	cd dist
$ java -jar SD_Servidor.jar


````
$

## Após isto é só verificar os arquivos de saída

	OBS: Os códigos fontes estão dentro do diretório principal (JogoDosOito) pasta src.


##

## O projeto possui Javadoc


	Para abrir navegue até o diretório principal(JogoDosOito)
	Depois abra a pasta dist/javadoc e dê dois cliques no arquivo index.html

	Após isto é sera aberto o browser para exibicao do javadoc


##