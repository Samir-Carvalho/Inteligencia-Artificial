# TrabalhoIA_JogoDos8
Trabalho de Inteligencia Artificial - Jogo Dos 8

- Trabalho desenvolvido em c++.

- Compile e execute o main.cpp

- Bibliotecas Utilizadas 
#include <cstdio>
#include <iostream>
#include <queue>
#include <string>
#include <stack>
#include <stdlib.h>
#include <set>
#include <chrono>
#include <cmath>

Entrada para a matriz da solução do jogo:
1 2 3
8 0 4
7 6 5

Exemplo de entrada para a matriz do jogo com os números embaralhados
3 4 2
5 1 7
6 0 8

Após isso, figite 1 para executar a busca em profundidade e 2 para executar a busca A*




Nome dos membros do grupo: Samir Avelino Carvalho e Vitor de Paula Batista
Link do vídeo:  https://youtu.be/LaD4_bqbY-o

